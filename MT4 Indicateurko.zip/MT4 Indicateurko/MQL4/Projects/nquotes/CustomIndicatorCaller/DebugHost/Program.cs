﻿
namespace NQuotes.DebugHost
{
    public class Program
    {
        public static void Main(string[] args)
        {
            NQuotes.DebugHost.Server.Start(args);
        }
    }
}
